// /src/api/chat.ts
import axios from 'axios';

const client = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,
});

export interface ConversationSummary {
  id: string;
  participants: string[];
  lastMessage?: { content: string; timestamp: string; };
  unreadCount: number;
}

export async function fetchConversations(): Promise<ConversationSummary[]> {
  const resp = await client.get('/chat/conversations');
  return resp.data;
}

export async function fetchHistory(to: string, limit = 50) {
  const resp = await client.get(`/chat/history?to=${to}&limit=${limit}`);
  return resp.data.history;
}

export interface MessagePayload {
  id: string;
  conversationId: string;
  from: string;
  to: string;
  content: string;
  timestamp: string;
}

export async function fetchMessages(conversationId: string): Promise<MessagePayload[]> {
  const resp = await client.get(`/chat/${conversationId}/messages`);
  return resp.data;
}