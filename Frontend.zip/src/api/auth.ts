import axios from 'axios';
import { getToken } from '../utils/auth';

const client = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,
});

// Attach token to requests
client.interceptors.request.use((config) => {
  const token = getToken();
  if (token) config.headers!['Authorization'] = `Bearer ${token}`;
  return config;
});

export interface LoginResponse { token: string; user: { id: string; username: string; } }

export async function loginAPI(username: string, password: string): Promise<LoginResponse> {
  const resp = await client.post('/auth/login', { username, password });
  return resp.data;
}

export async function registerAPI(username: string, email: string, password: string) {
  const resp = await client.post('/auth/register', { username, email, password });
  return resp.data;
}

export async function logoutAPI() {
  await client.post('/auth/logout');
}