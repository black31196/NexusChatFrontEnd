import { io, Socket } from 'socket.io-client';
import { getToken } from '../utils/auth';

export function createSocket(): Socket {
  return io(import.meta.env.VITE_WS_URL!, {
    auth: { token: getToken() },
    transports: ['websocket'],
    reconnectionAttempts: 5,
  });
}