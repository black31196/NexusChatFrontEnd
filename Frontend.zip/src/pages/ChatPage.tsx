import React, { useEffect } from 'react';
import { useChat } from '../hooks/useChat';
import Sidebar from '../components/Sidebar';
import ChatWindow from '../components/ChatWindow';
import { fetchConversations, fetchMessages } from '../api/chat';

export default function ChatPage() {
  const { conversations, selectConversation, currentConversationId, messages, sendMessage } = useChat();

  useEffect(() => {
    (async () => {
      const data = await fetchConversations();
      // TODO: set conversations in context (via dispatch)
    })();
  }, []);

  useEffect(() => {
    if (!currentConversationId) return;
    (async () => {
      const msgs = await fetchMessages(currentConversationId);
      // TODO: set messages in context
    })();
  }, [currentConversationId]);

  return (
    <div className="flex h-screen">
      <Sidebar
        conversations={conversations}
        onSelect={selectConversation}
        currentId={currentConversationId}
      />
      <ChatWindow
        messages={messages}
        onSend={sendMessage}
      />
    </div>
  );
}