import type { Conversation } from '../contexts/ChatContext';

interface Props {
  conversations: Conversation[];
  currentId?: string;
  onSelect: (id: string) => void;
}

export default function Sidebar({ conversations, currentId, onSelect }: Props) {
  return (
    <aside className="w-64 bg-gray-100 p-4 overflow-y-auto">
      {conversations.map((c) => (
        <div
          key={c.id}
          className={`p-2 mb-2 rounded cursor-pointer ${c.id === currentId ? 'bg-blue-200' : ''}`}
          onClick={() => onSelect(c.id)}
        >
          <div>{c.participants.join(', ')}</div>
          <small className="text-gray-600 text-sm">{c.lastMessage?.content}</small>
        </div>
      ))}
    </aside>
  );
}