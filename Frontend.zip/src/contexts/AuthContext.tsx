import React, { createContext, useState, useEffect } from 'react';
import { getToken, setToken, removeToken } from '../utils/auth';
import { loginAPI, logoutAPI } from '../api/auth';

interface User { id: string; username: string; }
interface AuthContextValue {
  user: User | null;
  token: string | null;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

export const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setTokenState] = useState<string | null>(getToken());

  useEffect(() => {
    const t = getToken();
    if (t) {
      setTokenState(t);
      // Optionally fetch and set user profile here
    }
  }, []);

  const login = async (username: string, password: string) => {
    const res = await loginAPI(username, password);
    setToken(res.token);
    setTokenState(res.token);
    setUser(res.user);
  };

  const logout = async () => {
    await logoutAPI();
    removeToken();
    setTokenState(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, token, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};