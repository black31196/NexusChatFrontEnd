import React, { createContext, useState, useEffect, useRef, ReactNode } from 'react';
import { createSocket } from '../services/socket';
import { Socket } from 'socket.io-client';
import { useAuth } from '../hooks/useAuth';

// Define message & conversation types
export interface Message {
  id: string;
  conversationId: string;
  from: string;
  to: string;
  content: string;
  timestamp: string;
  status: 'sending' | 'sent' | 'delivered';
}

export interface Conversation {
  id: string;
  participants: string[];
  lastMessage?: Message;
  unreadCount: number;
}

interface ChatContextValue {
  conversations: Conversation[];
  currentConversationId?: string;
  messages: Message[];
  selectConversation: (id: string) => void;
  sendMessage: (content: string) => void;
}

export const ChatContext = createContext<ChatContextValue | undefined>(undefined);

export const ChatProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { token, user } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentConversationId, setCurrentConversationId] = useState<string>();
  const [messages, setMessages] = useState<Message[]>([]);
  const socketRef = useRef<Socket>();

  // Initialize WebSocket when token is available
  useEffect(() => {
    if (!token) return;
    const socket = createSocket();

    socket.on('message:new', (msg: Message) => {
      if (msg.conversationId === currentConversationId) {
        setMessages((prev) => [...prev, msg]);
      }
      setConversations((prev) => {
        const exists = prev.find((c) => c.id === msg.conversationId);
        if (exists) {
          return prev.map((c) =>
            c.id === msg.conversationId
              ? { ...c, lastMessage: msg, unreadCount: c.unreadCount + 1 }
              : c
          );
        }
        return [
          { id: msg.conversationId, participants: [msg.from, msg.to], lastMessage: msg, unreadCount: 1 },
          ...prev,
        ];
      });
    });

    socketRef.current = socket;
    return () => { socket.disconnect(); };
  }, [token, currentConversationId]);

  const selectConversation = (id: string) => {
    setCurrentConversationId(id);
    setMessages([]);
    // TODO: Fetch history via REST API & reset unread count
  };

  const sendMessage = (content: string) => {
    if (!socketRef.current || !user || !currentConversationId) return;
    const tempId = Date.now().toString();
    const msg: Message = { id: tempId, conversationId: currentConversationId, from: user.id, to: currentConversationId, content, timestamp: new Date().toISOString(), status: 'sending' };
    setMessages((prev) => [...prev, msg]);

    socketRef.current.emit('message:send', msg, (ack: { id: string; timestamp: string }) => {
      setMessages((prev) => prev.map((m) => m.id === tempId ? { ...m, id: ack.id, timestamp: ack.timestamp, status: 'sent' } : m));
    });
  };

  return (
    <ChatContext.Provider value={{ conversations, currentConversationId, messages, selectConversation, sendMessage }}>
      {children}
    </ChatContext.Provider>
  );
};